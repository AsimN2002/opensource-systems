<?php
// Replace 'your_username' with your actual MySQL username
$servername = "localhost";
$username = "root";
$password = "your_password";
$database = "db1_your_username"; // Database from Week 5 practical

// Create connection
$conn = new mysqli("localhost", "root", "", "logbook5");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form data is set and not empty
$name = isset($_POST['txtName']) ? $_POST['txtName'] : '';
$email = isset($_POST['txtEmail']) ? $_POST['txtEmail'] : '';
$phone = isset($_POST['txtPhoneNumber']) ? $_POST['txtPhoneNumber'] : '';

// Ensure the form fields are not empty before proceeding
if ($name && $email && $phone) {
    // Prepare and bind to avoid SQL injection
    $stmt = $conn->prepare("INSERT INTO test (name, email, phone_number) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $phone); // 'sss' for three string parameters

    // Execute the statement
    if ($stmt->execute()) {
        echo "New record created successfully!<br><br>";
    } else {
        echo "Error: " . $stmt->error . "<br>";
    }

    // Close statement
    $stmt->close();
} else {
    echo "Please fill in all the required fields.";
}

// Retrieve and display all records
$sql = "SELECT * FROM test";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Current Records:</h2>";
    while ($row = $result->fetch_assoc()) {
        echo $row['name'] . " - " . $row['email'] . " - " . $row['phone_number'] . "<br>";
    }
} else {
    echo "No records found.";
}

// Close connection
$conn->close();
?>
