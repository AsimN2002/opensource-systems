<html>
<head>
    <title>My Guestbook</title>
</head>
<body>

<h1>Welcome to my Guestbook</h1>
<h2>Please write me a little note below</h2>

<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
    <textarea cols="40" rows="5" name="note" wrap="virtual"></textarea><br/>
    <input type="submit" value="Send it">
</form>

<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$file_name = "yourLogin.txt"; // Use a consistent filename for storage

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["note"])) {
        // Open file in append mode
        $fp = fopen($file_name, "a");
        fputs($fp, nl2br(htmlspecialchars($_POST["note"])) . "\n"); // Secure input
        fclose($fp);
    }
}
?>

<h2>The entries so far:</h2>

<?php
// Display the guestbook entries
if (file_exists($file_name)) {
    readfile($file_name);
} else {
    echo "No entries yet.";
}
?>

</body>
</html>