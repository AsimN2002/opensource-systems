<html>
<body>
<?php
    $hourlyrate = 5.75;
    $hoursperweek = 40;
    $gross = $hourlyrate * $hoursperweek;
    $tax_rate = 0.22;  // 22% tax rate
    $net = $gross * (1 - $tax_rate);
    
    echo "Gross Salary: £" . $gross . "<br>";
    echo "Net Salary after 22% tax: £" . $net;
?>
</body>
</html>