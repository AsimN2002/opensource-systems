<html>
<head>
    <title>Select Colour Page</title>
</head>
<body>
    <?php
    if (!isset($_POST["selqty"]) || !isset($_POST["selsize"])) {
        echo "<h2>Error: Quantity or Size not selected. Please go back to <a href='size.php'>size.php</a>.</h2>";
        exit();
    }
    ?>

    <form action="confirmation.php" method="post">
        <h2>Select the colour for <?php echo htmlspecialchars($_POST["selqty"]); ?> <?php echo htmlspecialchars($_POST["selsize"]); ?> widgets you are ordering</h2>
        
        <select name="selcolour">
            <option>White</option>
            <option>Red</option>
            <option>Yellow</option>
            <option>Green</option>
            <option>Blue</option>
        </select>
        <br/><br/>

        <!-- Hidden fields to pass quantity and size -->
        <input type="hidden" name="selqty" value="<?php echo htmlspecialchars($_POST["selqty"]); ?>">
        <input type="hidden" name="selsize" value="<?php echo htmlspecialchars($_POST["selsize"]); ?>">

        <input type="submit" value="Confirm"/>
    </form>
</body>
</html>