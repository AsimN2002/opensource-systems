<?php
session_start();
$conn = new mysqli("localhost", "root", "", "logbook5");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure directories exist
$imageDir = "images/";
$audioDir = "audio/";

if (!is_dir($imageDir)) {
    mkdir($imageDir, 0777, true);
}
if (!is_dir($audioDir)) {
    mkdir($audioDir, 0777, true);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $monsterName = $conn->real_escape_string($_POST['txtname']);

    // Handle image upload
    if (isset($_FILES["monsterimage"]) && $_FILES["monsterimage"]["error"] == UPLOAD_ERR_OK) {
        $imageFile = $imageDir . basename($_FILES["monsterimage"]["name"]);
        $imageFileType = strtolower(pathinfo($imageFile, PATHINFO_EXTENSION));
        
        $allowedImageTypes = ["jpg", "jpeg", "png"];
        if (!in_array($imageFileType, $allowedImageTypes)) {
            die("Error: Only JPG, JPEG, and PNG files are allowed for images.");
        }
        
        if (!move_uploaded_file($_FILES["monsterimage"]["tmp_name"], $imageFile)) {
            die("Error: Could not move uploaded image file.");
        }
    } else {
        die("Error: Image file upload failed. Error code: " . $_FILES["monsterimage"]["error"]);
    }

    // Handle audio upload
    if (isset($_FILES["monsteraudio"]) && $_FILES["monsteraudio"]["error"] == UPLOAD_ERR_OK) {
        $audioFile = $audioDir . basename($_FILES["monsteraudio"]["name"]);
        $audioFileType = strtolower(pathinfo($audioFile, PATHINFO_EXTENSION));

        $allowedAudioTypes = ["wav", "mp3"];
        if (!in_array($audioFileType, $allowedAudioTypes)) {
            die("Error: Only WAV and MP3 files are allowed for audio.");
        }
        
        if (!move_uploaded_file($_FILES["monsteraudio"]["tmp_name"], $audioFile)) {
            die("Error: Could not move uploaded audio file.");
        }
    } else {
        die("Error: Audio file upload failed. Error code: " . $_FILES["monsteraudio"]["error"]);
    }

    // Store filenames in the database
    $imageName = basename($imageFile);
    $audioName = basename($audioFile);

    $stmt = $conn->prepare("INSERT INTO monster (name, image, audio) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $monsterName, $imageName, $audioName);

    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Monster details saved successfully!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
    <h2>Monster Details</h2>
    <form enctype="multipart/form-data" action="" method="post">
        <div class="form-group">
            <label for="txtname">Monster Name:</label>
            <input type="text" name="txtname" id="txtname" class="form-control" required />
        </div>
        <div class="form-group">
            <label for="monsterimage">Monster Image:</label>
            <input type="file" name="monsterimage" id="monsterimage" accept="image/jpeg, image/png" class="form-control" required />
        </div>
        <div class="form-group">
            <label for="monsteraudio">Monster Sound:</label>
            <input type="file" name="monsteraudio" id="monsteraudio" accept="audio/wav, audio/mp3" class="form-control" required />
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-primary" value="Save" />
        </div>
    </form>
</body>
</html>