<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "logbook5"); // Change database name

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get POST data and sanitize it
$name = isset($_POST['txtname']) ? $conn->real_escape_string($_POST['txtname']) : '';
$phone = isset($_POST['txttelno']) ? $conn->real_escape_string($_POST['txttelno']) : '';
$email = isset($_POST['txtemail']) ? $conn->real_escape_string($_POST['txtemail']) : '';

// Update query
$sql = "UPDATE test SET phone_number = '$phone', email = '$email' WHERE name = '$name'";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully! <a href='wk6ex2.php'>Go back</a>";
} else {
    echo "Error updating record: " . $conn->error;
}

// Close connection
$conn->close();
?>