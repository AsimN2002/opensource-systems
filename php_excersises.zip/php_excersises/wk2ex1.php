<?php
$hourlyrate = 5.75;
$hoursperweek = 40;
$gross = $hourlyrate * $hoursperweek;
?>
<html>
<head><title>Exercise 1</title></head>
<body>
    <p> My gross wage is <?php print($gross); ?> </p>
</body>
</html>