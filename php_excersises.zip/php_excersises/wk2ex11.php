<?php
// Associative array with module codes as keys and marks as values
$mymarks = [
    "C0450-23S1BC" => 75, // Computer Architectures
    "C0454-23S1BC" => 80, // Digital Technologies and Professional Practice
    "C0556-23S1BC" => 70, // Network Systems
    "C0452-23S1BC" => 85, // Programming Concepts
    "C0456-23S1BC" => 90, // Web Development
    "C0453-23S2BC" => 88  // Application Programming
];

$total = 0; // Initialize total to zero

// Loop through the array to display marks and calculate total
foreach ($mymarks as $index => $value) {
    echo "Module $index: $value <br/>";
    
    // Adding each module mark to total using the exact formula you provided
    $total = $total + $mymarks[$index];
}

// Using your specific calculation for the average
$average = $total / 6;

echo "<br/> My total marks: $total";
echo "<br/> My average mark is: $average";
?>