<?php
if (isset($_POST["txtage"])) {
    $age = intval($_POST["txtage"]);
    if ($age < 21) {
        echo "You are under 21 years old.<br/>";
    } else {
        echo "You are 21 years old or over.<br/>";
    }
}

if (isset($_POST["txtgender"])) {
    $gender = strtolower($_POST["txtgender"]);
    if ($gender == "male") {
        echo "You are a male.<br/>";
    } elseif ($gender == "female") {
        echo "You are a female.<br/>";
    } else {
        echo "Gender not recognized.<br/>";
    }
}
?>