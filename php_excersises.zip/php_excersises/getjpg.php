<?php
$conn = new mysqli("localhost", "root", "", "logbook5");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Ensure ID is an integer
    $sql = "SELECT Image FROM monster WHERE id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($imageData);
    $stmt->fetch();
    $stmt->close();

    if ($imageData) {
        header("Content-Type: image/jpeg"); // Change based on your image type (jpeg/png)
        echo $imageData;
    } else {
        echo "Image not found!";
    }
} else {
    echo "No ID specified.";
}

$conn->close();
?>