<html>
<body>
<?php
    $myfavouritemodule = "Internet Systems Development";
    echo $myfavouritemodule;
?>
</body>
</html>