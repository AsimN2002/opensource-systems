<?php

  header("Content-type: audio/wav");

  $conn = new mysqli("localhost", "root", "", "logbook5"); // No password

  $sql = "SELECT audio FROM monster WHERE id='" . $_GET[id] ."';";
	
  $result = mysqli_query($sql, $conn);
  $row = mysqli_fetch_array($result);
  
  $audio = $row["audio"];

  echo $audio;
?>