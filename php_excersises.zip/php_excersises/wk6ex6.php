<?php
include("myfunctions.inc");

html_header("My second function demo");

$salary = 20000; // Change this to your salary
$tax_rate = 22;  // Change this to your tax rate
$allowance = 12570; // Change this to your tax-free allowance

echo "I pay £" . calculatetax($salary, $tax_rate, $allowance) . " tax.";

html_footer();
?>
