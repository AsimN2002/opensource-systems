<?php
$conn = new mysqli("localhost", "root", "", "logbook5");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $monsterName = $conn->real_escape_string($_POST['txtname']);

    // Define upload directories
    $imageDir = "images/";
    $audioDir = "audio/";

    // Ensure directories exist
    if (!is_dir($imageDir)) {
        mkdir($imageDir, 0777, true);
    }
    if (!is_dir($audioDir)) {
        mkdir($audioDir, 0777, true);
    }

    // Handle image upload
    $imageFile = $imageDir . basename($_FILES["monsterimage"]["name"]);
    $imageFileType = strtolower(pathinfo($imageFile, PATHINFO_EXTENSION));

    // Handle audio upload
    $audioFile = $audioDir . basename($_FILES["monsteraudio"]["name"]);
    $audioFileType = strtolower(pathinfo($audioFile, PATHINFO_EXTENSION));

    // Allowed file types
    $allowedImageTypes = ["jpg", "jpeg", "png"];
    $allowedAudioTypes = ["wav", "mp3"];

    if (!in_array($imageFileType, $allowedImageTypes)) {
        die("Error: Only JPG, JPEG, and PNG files are allowed for images.");
    }

    if (!in_array($audioFileType, $allowedAudioTypes)) {
        die("Error: Only WAV and MP3 files are allowed for audio.");
    }

    // Check for upload errors
    if ($_FILES["monsterimage"]["error"] !== UPLOAD_ERR_OK) {
        die("Error uploading image: " . $_FILES["monsterimage"]["error"]);
    }

    if ($_FILES["monsteraudio"]["error"] !== UPLOAD_ERR_OK) {
        die("Error uploading audio: " . $_FILES["monsteraudio"]["error"]);
    }

    // Move uploaded files
    if (move_uploaded_file($_FILES["monsterimage"]["tmp_name"], $imageFile) &&
        move_uploaded_file($_FILES["monsteraudio"]["tmp_name"], $audioFile)) {
        
        // Store filenames in the database
        $imageName = basename($imageFile);
        $audioName = basename($audioFile);

        $stmt = $conn->prepare("INSERT INTO monster (name, image, audio) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $monsterName, $imageName, $audioName);

        if ($stmt->execute()) {
            echo "Monster details saved successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        die("Error moving uploaded files.");
    }
}

$conn->close();
?>