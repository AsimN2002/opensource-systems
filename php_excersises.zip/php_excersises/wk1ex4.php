<html>
<body>
<?php
    echo "Day: " . gmdate("D") . "<br>";
    echo "Full Date: " . gmdate("d m Y") . "<br>";
    echo "Day of the Year: " . gmdate("z");
?>
</body>
</html>