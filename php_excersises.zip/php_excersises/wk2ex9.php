<?php
$topmodules[0] = "Internet Systems Development";
$topmodules[5] = "Programming 1";
$topmodules[10] = "Programming 2";
$topmodules[30] = "OOAD";
$topmodules[40] = "Software Engineering";

// Foreach loop to display key-value pairs
foreach ($topmodules as $index => $value) {
    echo "Index is $index and value is $value <br/>";
}
?>