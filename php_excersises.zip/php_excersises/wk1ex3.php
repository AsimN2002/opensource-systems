<html>
<body>
<?php
	echo "Blimmy it worked!";

?>
</body>
</html>