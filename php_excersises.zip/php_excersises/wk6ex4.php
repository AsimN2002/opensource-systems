<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "logbook5");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the ID from URL or POST
$id = isset($_GET['id']) ? $conn->real_escape_string($_GET['id']) : (isset($_POST['id']) ? $conn->real_escape_string($_POST['id']) : '');

if ($id) {
    // Delete the record
    $sql = "DELETE FROM test WHERE name = '$id'";

    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully! <a href='wk6ex2.php'>Go back</a>";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "Invalid request. <a href='wk6ex2.php'>Go back</a>";
}

$conn->close();
?>