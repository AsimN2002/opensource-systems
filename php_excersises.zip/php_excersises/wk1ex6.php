<html>
<body>
<?php
    $firstname = "Richard";
    $lastname = "Mather";
    $space = " ";
    $name = $firstname . $space . $lastname;
    echo $name;
?>
</body>
</html>