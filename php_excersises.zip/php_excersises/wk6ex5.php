<?php
include("myfunctions.inc");

html_header("My first function demo");
html_h1("These functions are going to save me lots of time");

// Call the new html_h2 function
html_h2("This is a subheading using my new function!");

html_footer();
?>
