<?php
$conn = new mysqli("localhost", "root", "", "logbook5");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, name, image, audio FROM monster;";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $imagePath = "images/" . htmlspecialchars($row['image']);
        $audioPath = "audio/" . htmlspecialchars($row['audio']);
        $monsterName = htmlspecialchars($row['name']);

        echo "<div style='margin: 10px; padding: 10px; border: 1px solid #ccc; display: inline-block; text-align: center;'>";
        echo "<h3>$monsterName</h3>";

        // Display the image if it exists
        if (file_exists($imagePath)) {
            echo "<img src='$imagePath' width='200' height='200' alt='$monsterName' /><br>";
        } else {
            echo "<p style='color:red;'>Image not found: $imagePath</p>";
        }

        // Display the audio file if it exists
        if (file_exists($audioPath)) {
            echo "<audio controls>
                    <source src='$audioPath' type='audio/mpeg'>
                    Your browser does not support the audio element.
                  </audio><br>";
        } else {
            echo "<p style='color:red;'>Audio file not found: $audioPath</p>";
        }

        echo "</div>";
    }
} else {
    echo "<p>No monster records found.</p>";
}

$conn->close();
?>