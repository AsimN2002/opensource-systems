<?php
session_start(); // Start session if needed

// Database connection
$conn = mysqli_connect("localhost", "root", "", "logbook5");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['selweek'])) {
    // Sanitize input
    $selectedWeek = mysqli_real_escape_string($conn, $_POST['selweek']);

    // Fetch selected week's numbers
    $sql = "SELECT * FROM lotto WHERE lottodate = '$selectedWeek'";
    $result = mysqli_query($conn, $sql);

    if ($row = mysqli_fetch_assoc($result)) {
        echo "<br/><strong>Lottery Numbers for $selectedWeek:</strong><br/>";
        echo "Number 1 is {$row['number1']}<br/>";
        echo "Number 2 is {$row['number2']}<br/>";
        echo "Number 3 is {$row['number3']}<br/>";
        echo "Number 4 is {$row['number4']}<br/>";
        echo "Number 5 is {$row['number5']}<br/>";
        echo "Number 6 is {$row['number6']}<br/>";
    } else {
        echo "<br/>No lottery results found for this date.";
    }
} else {
    // Fetch all available lottery dates
    $sql = "SELECT lottodate FROM lotto";
    $result = mysqli_query($conn, $sql);

    echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>";
    echo "<br/>Select the lottery week ";
    echo "<select name='selweek'>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<option value='{$row['lottodate']}'>{$row['lottodate']}</option>";
    }

    echo "</select><br/>";
    echo "<input type='submit' value='Select' />";
    echo "</form>";
}

// Close the database connection
mysqli_close($conn);
?>