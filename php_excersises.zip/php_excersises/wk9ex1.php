<?php
     $lottodate = date("Ymd");
     echo "The lottery numbers for $lottodate are ";
     for($n=1;$n<7;$n++){
        $number[$n] = rand(1,49);
        echo "<br/> $number[$n]";
     }
     // Database connection
     $conn = new mysqli("localhost", "root", "", "logbook5");

     // Check connection
     if ($conn->connect_error) {
         die("Connection failed: " . $conn->connect_error);
     }

     // SQL query
     $sql = "INSERT INTO lotto (lottodate, number1, number2, number3, number4, number5, number6) 
             VALUES ($lottodate, $number[1], $number[2], $number[3], $number[4], $number[5], $number[6])";

     // Execute query
     if (mysqli_query($conn, $sql)) {
         echo "<br/>This week's numbers have been saved";
     } else {
         echo "<br/>Error: " . $conn->error;
     }

     // Close connection
     $conn->close();
?>